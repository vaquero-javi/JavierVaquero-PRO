import controller.Sistema;

import java.util.Scanner;

public class Entrada {
    /*
    Realizar una aplicación que gestione usuarios mediante una lista (tú
    decides cuál), donde los datos del alumno que se quieren guardar son nombre
    (string), apellido (string), teléfono (int), dni (string) y disponibilidad: La
    funcionalidad de la aplicación se guiará por un menú con las siguientes
    opciones:
        a. Agregar persona: Pedirá los datos de nombre, apellido, teléfono y dni.
    Una vez pedidos agregará la persona en la lista.
        b. Buscar persona: Pedirá un dni y sacará por pantalla todos los datos de la
    persona asociada con el formato Nombre: XXX, Apellido: XXX, Teléfono:
    XXX
        c. Borrar persona: Pedirá un dni y la eliminará de la lista
        d. Borrar sin disponibilidad: Borrará todas aquellas personas que no tengan
    disponibilidad
        e. Listar personas: Listará todos los elementos existentes en la lista con el
    formato Nombre: XXX, Apellido: XXX, Teléfono: XXX
    En todos los casos se deberá de dar confirmación al usuario tanto del éxito
    de la operación como de la ejecución incorrecta de la opción
     */

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Sistema sistema =




    }
}
