class Entrada {
}