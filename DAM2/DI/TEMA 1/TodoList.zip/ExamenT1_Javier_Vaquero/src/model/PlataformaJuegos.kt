package model

class PlataformaJuegos {
}