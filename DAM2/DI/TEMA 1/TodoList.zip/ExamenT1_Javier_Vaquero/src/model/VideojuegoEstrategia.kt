package model

class VideojuegoEstrategia {
}