package model

interface Descargable {
}