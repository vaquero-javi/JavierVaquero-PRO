package model

class VideojuegoAccion {
}