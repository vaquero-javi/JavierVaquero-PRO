package model

class VideojuegoRPG {
}