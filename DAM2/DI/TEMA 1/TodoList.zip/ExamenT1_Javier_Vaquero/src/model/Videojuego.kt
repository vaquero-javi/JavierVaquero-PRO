package model

abstract class Videojuego() {

    fun llamada(var titulo: String, var desarrollador: String,
                var anioLanzamiento: Int, var precio: Double, var clasificaionEdad: String){

    }

}

