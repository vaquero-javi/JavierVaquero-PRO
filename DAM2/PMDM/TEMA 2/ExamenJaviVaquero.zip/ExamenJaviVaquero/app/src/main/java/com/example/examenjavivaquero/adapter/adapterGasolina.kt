package com.example.examenjavivaquero.adapter

class adapterGasolina {
}