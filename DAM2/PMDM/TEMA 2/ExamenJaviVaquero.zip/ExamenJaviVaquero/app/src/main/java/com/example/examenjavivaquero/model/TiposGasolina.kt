package com.example.examenjavivaquero.model

class TiposGasolina() {
    var diesel: String
    var gasolina: String
    var hibrido: String
    var electrico: String

}