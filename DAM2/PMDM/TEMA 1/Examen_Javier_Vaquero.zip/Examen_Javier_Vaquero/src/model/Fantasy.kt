package model

class Fantasy(ArrayList<Jugador>) {

}