package com.example.usodecorrutinasandroid.model

data class TableResult(
    val n: Int,
    val rows: List<String>
)
