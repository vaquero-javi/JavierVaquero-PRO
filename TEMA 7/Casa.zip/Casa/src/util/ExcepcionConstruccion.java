package util;

public class ExcepcionConstruccion extends Exception {
    public ExcepcionConstruccion(String message) {
        super(message);
    }
}
