package util;

public enum Orientacion {
    NORTE, SUR, ESTE, OESTE;
}
