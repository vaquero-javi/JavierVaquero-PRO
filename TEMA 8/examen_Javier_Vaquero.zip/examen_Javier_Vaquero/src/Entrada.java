import java.io.File;

public class Entrada {
    public static void main(String[] args) {
        File file = new File("src/resources/ejercicio1.txt");
    }
}
