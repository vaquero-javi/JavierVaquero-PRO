public class Entrada {

}
