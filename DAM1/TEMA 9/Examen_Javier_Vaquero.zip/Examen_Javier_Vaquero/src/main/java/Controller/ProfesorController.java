package Controller;

public class ProfesorController {

}
